package com.example.preity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;

public class uploadInFirebase extends AppCompatActivity {

    Button button;
    final int SELECT_OK=100;
    VideoView videoView;
    Uri uri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_in_firebase);
       button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                videopicker();
            }
        });
    //    videoView = findViewById(R.id.videoView);
    //    MediaController mediaController = new MediaController(this);
    //    mediaController.setAnchorView(videoView);
    //    videoView.setMediaController(mediaController);
    //    videoView.setVideoURI(uri);
    }
    void videopicker()
    {
        Intent intent = new Intent();
        intent.setType("video/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent,"SELECT TO UPLOAD"), SELECT_OK);
    }
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode ==RESULT_OK) {
            if(requestCode == SELECT_OK)
            {

                try {
                  //  uri = data.getData();
                }
                catch (Exception e)
                {
                    Toast.makeText(getApplicationContext(), "OPS! SOMETHING WENT WRONG", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
}